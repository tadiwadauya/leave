<?php $__env->startComponent('mail::message'); ?>
<?php echo e($details['greeting']); ?>


<?php echo e($details['body']); ?>


<h4>Leave Summary</h4>
<table style="border: 0; width: 100%">
<tr>
<td style="border: 0;"><strong>Type of Leave</strong></td>
<td style="border: 0;"><?php echo e($details['body1']); ?></td>
</tr>
<tr>
<td style="border: 0;"><strong>Days Requested:</strong></td>
<td style="border: 0;"><?php echo e($details['body2']); ?></td>
</tr>
<tr>
<td style="border: 0;"><strong>Date From:</strong></td>
<td style="border: 0;"><?php echo e($details['body3']); ?></td>
</tr>
<tr>
<td style="border: 0;"><strong>Date To:</strong></td>
<td style="border: 0;"><?php echo e($details['body4']); ?></td>
</tr>
</table>

<?php echo e($details['body5']); ?>


<?php $__env->startComponent('mail::button', ['url' => $details['approveURL']]); ?>
Approve
<?php echo $__env->renderComponent(); ?>

<?php echo e($details['body6']); ?>


<table style="width: 100%">
<tr>
<td>
<?php $__env->startComponent('mail::button', ['url' => $details['rejectURL']]); ?>
Reject
<?php echo $__env->renderComponent(); ?>
</td>
</tr>
</table>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\whelsonleave\resources\views/emails/leaveapprove.blade.php ENDPATH**/ ?>