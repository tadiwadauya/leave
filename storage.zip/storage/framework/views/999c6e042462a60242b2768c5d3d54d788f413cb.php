<?php
/**
 * Created by PhpStorm for wls
 * User: Vincent Guyo
 * Date: 1/30/2020
 * Time: 7:45 AM
 */

$paynumber = AUth::user()->paynumber;

$specialCount = \App\Models\Leave::where('type_of_leave','=','Compassionate')->where('paynumber','=',$paynumber)->where('status','=',1)->whereYear('created_at', '=', date('Y'))->sum('days_taken');
//$specialCount = \App\Models\Leave::where('type_of_leave','=','Compassionate')->where('status','=',1)->whereYear('created_at', '=', date('Y'))->count();

$sickCount = \App\Models\Leave::where('type_of_leave','=','Sick')->where('paynumber','=',$paynumber)->where('status','=',1)->whereYear('created_at', '=', date('Y'))->sum('days_taken');
//$sickCount = \App\Models\Leave::where('type_of_leave','=','Sick')->where('status','=',1)->whereYear('created_at', '=', date('Y'))->count();
//dd($sickCount);
$maternityCount = \App\Models\Leave::where('type_of_leave','=','Maternity')->where('paynumber','=',$paynumber)->where('status','=',1)->count();
?>

<div class="card">
    <div class="card-header text-white  bg-success">
        <div style="display: flex; justify-content: space-between; align-items: center;">

            <?php
                $user = \App\Models\User::where('paynumber','=', $paynumber )->firstOrFail();
            ?>
            <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td> Leave Info

        </div>
    </div>

    <div class="card-body">
        Leave Balance: <?php echo e($user->leave_days); ?>

        <br>
        <small> <u> According to the SI 26 of 2017, Section 17 for Transport Operating Industry.</u></small>
        <ul class="list-group">

            Special/ Compassionate days taken: <?php echo e($specialCount); ?> / 12
            <br/>
            Sick days taken: <?php echo e($sickCount); ?> / 180
            <br/>
            Maternity days taken: <?php echo e($maternityCount); ?> / 3

        </ul>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\whelsonleave\resources\views/leaves/leave-sidebar.blade.php ENDPATH**/ ?>