<?php
/**
 * Created by PhpStorm.
 * User: Vincent Guyo
 * Date: 9/22/2019
 * Time: 17:41
 */
?>



<?php $__env->startSection('template_title'); ?>
    Request Leave
<?php $__env->stopSection(); ?>

<?php $__env->startSection('template_fastload_css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('template_linked_css'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.css')); ?>"/>
    <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet"/>
    <style>

        .ui-datepicker-prev, .ui-datepicker-next {
            width: 4em !important;
        }

        .ui-datepicker-title > span {
            font-size: .85em !important;
        }

        .ui-datepicker-prev > span, .ui-datepicker-next > span {
            text-indent: 0;
            margin: 0 !important;
            text-align: center;
            height: inherit !important;
            width: inherit !important;
            background: 0 !important;
            left: 0 !important;
            transform: translateY(-25%);
            font-size: .65em;
            font-weight: normal;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <body>

    <div class="flex-center position-ref full-height">

        <script src="<?php echo e(asset('js/custom_jquery.min.js')); ?>"></script>

        <div class="container">
            <div class="row">

                    <div class="col-lg-3">
                        <?php echo $__env->make('leaves.leave-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                <div class="col-lg-9">
                    <div class="card">

                        <div class="card-body">

                            <form method="post" action="<?php echo e(route('leaves.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <fieldset>
                                    <legend>Requesting For My Leave</legend>
                                    <div class="form-group col-lg-12">
                                        <div class="form-group col-lg-6">
                                                <input type="hidden" class="form-control" id="paynumber" name="paynumber" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->paynumber); ?>" readonly/>
                                        </div>

                                        <div class="form-group col-lg-6">
                                            <label for="type_of_leave">Type of Leave :</label>
                                            <select id="type_of_leave" class="form-control" name="type_of_leave">
                                                <option value="">Select Leave Type</option>
                                                <?php $__currentLoopData = $leave_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($e->leave_type); ?>" data-price=""
                                                            data-tag=""><?php echo e($e->leave_type); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                    </div>


                                    <div class="form-group">
                                        <input type="hidden" class="form-control" id="applier_name" name="applier_name" value="<?php echo e(AUth::user()->first_name); ?> <?php echo e(AUth::user()->last_name); ?>"/>
                                    </div>

                                    <div class="form-group">
                                        <label for="department">Department :</label>
                                        <input type="text" class="form-control" id="department" name="department" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->department); ?>"
                                               readonly/>
                                    </div>

                                    <div class="form-group">
                                        <label for="address">Address :</label>
                                        <input type="text" class="form-control" id="address" name="address" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->address); ?>" readonly/>
                                    </div>

                                    <div class="form-group">
                                        <label for="mobile">Mobile :</label>
                                        <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->mobile); ?>" readonly/>
                                    </div>

                                    <div class="form-group col-lg-12">
                                        <div class="form-group col-lg-6 ">
                                            <label for="mdate">Date From :</label>
                                            <input type="text" name="date_from" class="form-control datepicker"
                                                   id="datepicker" placeholder="e.g. 31-01-2019" required>
                                        </div>

                                    </div>

                                    <div class="form-group col-lg-12">

                                        <div class="form-group col-lg-6">
                                            <label for="date-only">Date To :</label>
                                            <input type="text" name="date_to" class="form-control datepicker"
                                                   id="datepicker2" placeholder="e.g. 31-01-2019" required>
                                        </div>
                                    </div>

                                    <div class="form-group col-lg-12">
                                        <div class="form-group col-lg-12 ">
                                            <label for="half_day">Half Day? :</label><em> (When requesting for a half
                                                day, please make sure you select the same date for "Date From:" and
                                                "Date To:" and select "Yes" below)</em><br/>
                                            <input type="radio" name="half_day" value="0" checked required>No
                                            <input type="radio" name="half_day" value="1" required>Yes
                                        </div>
                                    </div>

                                    

                                    <div class="form-group hidden">
                                        <input type="hidden" class="form-control" id="applied_by" name="applied_by"
                                               value="<?php echo e(AUth::user()->paynumber); ?>"/>
                                    </div>

                                    <!-- Submit Button -->
                                    <div class="form-group">
                                        <div class="col-lg-10 col-lg-offset-2">
                                            <button type="submit" class="btn btn-primary">Request Leave</button>
                                        </div>
                                    </div>

                                </fieldset>

                            </form>
                        </div>
                    </div>
                </div>



            </div>
        </div>
    </div>

    </body>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_scripts'); ?>

    <script src="<?php echo e(asset('js/custom_bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    
    <script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>

    <script>
        jQuery(document).ready(function ($) {
            $('.datepicker').datepicker({
                navigationAsDateFormat: true,
                dateFormat: "yy-mm-dd",
                minDate: new Date(),
                nextText: 'MM',
                prevText: 'MM'
            });
        });

        jQuery(document).ready(function ($) {
            $('.datepicker2').datepicker({
                navigationAsDateFormat: true,
                dateFormat: "yy-mm-dd"
            });
        });
    </script>


    <script type="text/javascript">

        $("#type_of_leave").select2({
            placeholder: 'Please select a Leave Type',
            allowClear: true,
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\whelsonleave\resources\views/leaves/create.blade.php ENDPATH**/ ?>