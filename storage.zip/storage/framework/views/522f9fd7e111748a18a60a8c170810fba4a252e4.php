<tr>
<td>
<table class="footer" align="center" width="570" cellpadding="0" cellspacing="0">
<tr>
<td class="content-cell" align="center">
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?> Whelson GDC Transport
</td>
</tr>
</table>
</td>
</tr>
<?php /**PATH C:\xampp\htdocs\whelsonleave\resources\views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>