<nav class="navbar navbar-expand-md navbar-light navbar-laravel">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/home')); ?>">
            <?php echo config('app.name', trans('titles.app')); ?>

        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            <span class="sr-only"><?php echo trans('titles.toggleNav'); ?></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            
            <ul class="navbar-nav mr-auto">
                <?php if (Auth::check() && Auth::user()->hasRole('admin')): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Users
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item <?php echo e(Request::is('users', 'users/' . Auth::user()->id, 'users/' . Auth::user()->id . '/edit') ? 'active' : null); ?>" href="<?php echo e(url('/users')); ?>">
                            <?php echo trans('titles.adminUserList'); ?>

                        </a>

                        <div class="dropdown-divider"></div>

                        <a class="dropdown-item <?php echo e(Request::is('drivers', 'drivers/*') ? 'active' : null); ?>" href="<?php echo e(url('/drivers')); ?>">
                            Drivers Administration
                        </a>

                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('roles') || Request::is('permissions')) ? 'active' : null); ?>" href="<?php echo e(route('laravelroles::roles.index')); ?>">
                            <?php echo trans('titles.laravelroles'); ?>

                        </a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Departments
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item"  href="<?php echo e(url('/departments')); ?>">
                            Departments
                        </a>


                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Job Titles
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item"  href="<?php echo e(url('/jobtitles')); ?>">
                            Job Titles
                        </a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Leaves
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item <?php echo e((Request::is('leaves') || Request::is('leaves')) ? 'active' : null); ?>"  href="<?php echo e(url('/leaves')); ?>">
                            Leave List
                        </a>

                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('manage-leave') || Request::is('manage-leave')) ? 'active' : null); ?>" href="<?php echo e(route('manage-leave')); ?>">
                            Manage Leave Requests
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('leave-calendar') || Request::is('leave-calendar')) ? 'active' : null); ?>" href="<?php echo e(route('leave-calendar')); ?>">
                            Leave Calendar
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('leave-records') || Request::is('leave-records')) ? 'active' : null); ?>" href="<?php echo e(route('leave-records')); ?>">
                            Leave Records
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('leave-balances') || Request::is('leave-balances')) ? 'active' : null); ?>" href="<?php echo e(route('leave.balances')); ?>">
                            Leave Balances
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('leave-administration') || Request::is('leave-administration')) ? 'active' : null); ?>" href="<?php echo e(route('leave.admin')); ?>">
                            Administration
                        </a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Driver Leaves
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item <?php echo e((Request::is('driverleaves') || Request::is('driverleaves')) ? 'active' : null); ?>"  href="<?php echo e(url('/driverleaves')); ?>">
                            Driver Leave List
                        </a>

                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('manage-driver-leave') || Request::is('manage-driver-leave')) ? 'active' : null); ?>" href="<?php echo e(route('manage-driverleave')); ?>">
                            Manage Driver Leave Requests
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('driver-leave-records') || Request::is('driver-leave-records')) ? 'active' : null); ?>" href="<?php echo e(route('driverleave-records')); ?>">
                            Driver Leave Records
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('driver-leave-balances') || Request::is('driver-leave-balances')) ? 'active' : null); ?>" href="<?php echo e(route('driverleave.balances')); ?>">
                            Driver Leave Balances
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('driver-leave-administration') || Request::is('driver-leave-administration')) ? 'active' : null); ?>" href="<?php echo e(route('driverleave.admin')); ?>">
                            Administration
                        </a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Settings
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item <?php echo e((Request::is('roles') || Request::is('permissions')) ? 'active' : null); ?>" href="<?php echo e(route('laravelroles::roles.index')); ?>">
                            <?php echo trans('titles.laravelroles'); ?>

                        </a>

                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e(Request::is('themes','themes/create') ? 'active' : null); ?>" href="<?php echo e(url('/themes')); ?>">
                            <?php echo trans('titles.adminThemesList'); ?>

                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e(Request::is('logs') ? 'active' : null); ?>" href="<?php echo e(url('/logs')); ?>">
                            <?php echo trans('titles.adminLogs'); ?>

                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e(Request::is('activity') ? 'active' : null); ?>" href="<?php echo e(url('/activity')); ?>">
                            <?php echo trans('titles.adminActivity'); ?>

                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e(Request::is('phpinfo') ? 'active' : null); ?>" href="<?php echo e(url('/phpinfo')); ?>">
                            <?php echo trans('titles.adminPHP'); ?>

                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e(Request::is('routes') ? 'active' : null); ?>" href="<?php echo e(url('/routes')); ?>">
                            <?php echo trans('titles.adminRoutes'); ?>

                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e(Request::is('active-users') ? 'active' : null); ?>" href="<?php echo e(url('/active-users')); ?>">
                            <?php echo trans('titles.activeUsers'); ?>

                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e(Request::is('blocker') ? 'active' : null); ?>" href="<?php echo e(route('laravelblocker::blocker.index')); ?>">
                            <?php echo trans('titles.laravelBlocker'); ?>

                        </a>
                    </div>
                </li>
                <?php endif; ?>

                <?php if (Auth::check() && Auth::user()->hasRole('director')): ?>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Department
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item"  href="<?php echo e(url('/departmental-users')); ?>">
                            My Department Users
                        </a>


                    </div>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e((Request::is('leaves/create') ) ? 'active' : null); ?>" href="<?php echo e(url('/leaves/create')); ?>" id="navbarDropdown" role="button">
                        Apply for Leave
                    </a>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Leaves
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item <?php echo e((Request::is('leaves') || Request::is('leaves')) ? 'active' : null); ?>"  href="<?php echo e(url('/leaves')); ?>">
                            Leave List
                        </a>

                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('manage-leave') || Request::is('manage-leave')) ? 'active' : null); ?>" href="<?php echo e(route('manage-leave')); ?>">
                            Manage Leave Requests
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('leave-calendar') || Request::is('leave-calendar')) ? 'active' : null); ?>" href="<?php echo e(route('leave-calendar')); ?>">
                            Leave Calendar
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('leave-records') || Request::is('leave-records')) ? 'active' : null); ?>" href="<?php echo e(route('leave-records')); ?>">
                            Leave Records
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('leave-balances') || Request::is('leave-balances')) ? 'active' : null); ?>" href="<?php echo e(route('leave.balances')); ?>">
                            Leave Balances
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('leave-administration') || Request::is('leave-administration')) ? 'active' : null); ?>" href="<?php echo e(route('leave.admin')); ?>">
                            Administration
                        </a>
                    </div>
                </li>

                <?php endif; ?>

                <?php if (Auth::check() && Auth::user()->hasRole('manager')): ?>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Department
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item"  href="<?php echo e(url('/departmental-users')); ?>">
                            My Department Users
                        </a>


                    </div>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e((Request::is('leaves/create') ) ? 'active' : null); ?>" href="<?php echo e(url('/leaves/create')); ?>" id="navbarDropdown" role="button">
                        Apply for Leave
                    </a>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Leaves
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item <?php echo e((Request::is('leaves') || Request::is('leaves')) ? 'active' : null); ?>"  href="<?php echo e(url('/leaves')); ?>">
                            Leave List
                        </a>

                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('manage-leave') || Request::is('manage-leave')) ? 'active' : null); ?>" href="<?php echo e(route('manage-leave')); ?>">
                            Manage Leave Requests
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('leave-calendar') || Request::is('leave-calendar')) ? 'active' : null); ?>" href="<?php echo e(route('leave-calendar')); ?>">
                            Leave Calendar
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('leave-records') || Request::is('leave-records')) ? 'active' : null); ?>" href="<?php echo e(route('leave-records')); ?>">
                            Leave Records
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('leave-balances') || Request::is('leave-balances')) ? 'active' : null); ?>" href="<?php echo e(route('leave.balances')); ?>">
                            Leave Balances
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('leave-administration') || Request::is('leave-administration')) ? 'active' : null); ?>" href="<?php echo e(route('leave.admin')); ?>">
                            Administration
                        </a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Driver Leaves
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item <?php echo e((Request::is('driverleaves') || Request::is('driverleaves')) ? 'active' : null); ?>"  href="<?php echo e(url('/driverleaves')); ?>">
                            Driver Leave List
                        </a>

                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('manage-driver-leave') || Request::is('manage-driver-leave')) ? 'active' : null); ?>" href="<?php echo e(route('manage-driverleave')); ?>">
                            Manage Driver Leave Requests
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('driver-leave-records') || Request::is('driver-leave-records')) ? 'active' : null); ?>" href="<?php echo e(route('driverleave-records')); ?>">
                            Driver Leave Records
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('driver-leave-balances') || Request::is('driver-leave-balances')) ? 'active' : null); ?>" href="<?php echo e(route('driverleave.balances')); ?>">
                            Driver Leave Balances
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('driver-leave-administration') || Request::is('driver-leave-administration')) ? 'active' : null); ?>" href="<?php echo e(route('driverleave.admin')); ?>">
                            Administration
                        </a>
                    </div>
                </li>

                <?php endif; ?>

                <?php if (Auth::check() && Auth::user()->hasRole('hrmaingate')): ?>

                    <li class="nav-item">
                        <a class="nav-link <?php echo e((Request::is('leaves/create') ) ? 'active' : null); ?>" href="<?php echo e(url('/leaves/create')); ?>" id="navbarDropdown" role="button">
                            Apply for Leave
                        </a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Leaves
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item <?php echo e((Request::is('leaves') || Request::is('leaves')) ? 'active' : null); ?>"  href="<?php echo e(url('/leaves')); ?>">
                                Leave List
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item <?php echo e((Request::is('leave-records') || Request::is('leave-records')) ? 'active' : null); ?>" href="<?php echo e(route('leave-records')); ?>">
                                Leave Records
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item <?php echo e((Request::is('leave-balances') || Request::is('leave-balances')) ? 'active' : null); ?>" href="<?php echo e(route('leave.balances')); ?>">
                                Leave Balances
                            </a>

                        </div>
                    </li>

                <?php endif; ?>

                <?php if (Auth::check() && Auth::user()->hasRole('user')): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e((Request::is('leaves/create') ) ? 'active' : null); ?>" href="<?php echo e(url('/leaves/create')); ?>" id="navbarDropdown" role="button">
                        Apply for Leave
                    </a>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Leaves
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item <?php echo e((Request::is('leaves') || Request::is('leaves')) ? 'active' : null); ?>"  href="<?php echo e(url('/leaves')); ?>">
                            Leave List
                        </a>

                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e((Request::is('leave-calendar') || Request::is('leave-calendar')) ? 'active' : null); ?>" href="<?php echo e(route('leave-calendar')); ?>">
                            Leave Calendar
                        </a>

                    </div>
                </li>
                <?php if(auth()->user()->department == 'Operations'): ?>

                    <li class="nav-item">
                        <a class="nav-link <?php echo e((Request::is('driverleaves/create') ) ? 'active' : null); ?>" href="<?php echo e(url('/driverleaves/create')); ?>" id="navbarDropdown" role="button">
                            Apply Driver Leave
                        </a>
                    </li>

                    <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Drivers
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item <?php echo e((Request::is('driverleaves') || Request::is('driverleaves')) ? 'active' : null); ?>"  href="<?php echo e(url('/driverleaves')); ?>">
                            Driver Leave List
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item <?php echo e(Request::is('drivers', 'drivers/*') ? 'active' : null); ?>" href="<?php echo e(url('/drivers')); ?>">
                            Drivers Administration
                        </a>

                    </div>

                </li>
                <?php endif; ?>

                <?php endif; ?>
            </ul>

            
            <ul class="navbar-nav ml-auto">
                
                <?php if(auth()->guard()->guest()): ?>
                    <li><a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(trans('titles.login')); ?></a></li>
                    <li><a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(trans('titles.register')); ?></a></li>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php if((Auth::User()->profile) && Auth::user()->profile->avatar_status == 1): ?>
                                <img src="<?php echo e(Auth::user()->profile->avatar); ?>" alt="<?php echo e(Auth::user()->name); ?>" class="user-avatar-nav">
                            <?php else: ?>
                                <div class="user-avatar-nav"></div>
                            <?php endif; ?>
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item <?php echo e(Request::is('profile/'.Auth::user()->name, 'profile/'.Auth::user()->name . '/edit') ? 'active' : null); ?>" href="<?php echo e(url('/profile/'.Auth::user()->name)); ?>">
                                <?php echo trans('titles.profile'); ?>

                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\whelsonleave\resources\views/partials/nav.blade.php ENDPATH**/ ?>